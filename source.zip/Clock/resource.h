//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by clock.rc
//
#define IDS_ROMAN                       1
#define IDS_ARABIC                      2
#define ID_MYICON                       101
#define IDD_CLOCK_DIALOG                102
#define IDD_THEMEDLG                    103
#define IDR_MAINFRAME                   128
#define IDR_POPUP                       129
#define IDD_ABOUT                       130
#define IDC_ROMAN                       1000
#define IDC_Rotate                      1001
#define IDC_QUADONLY                    1002
#define IDC_X                           1003
#define IDC_Y                           1004
#define IDC_CX                          1005
#define IDC_CY                          1006
#define IDC_SMOOTH                      1007
#define IDC_COLORBOX1                   1008
#define IDC_COLORBOX2                   1009
#define IDC_COLORBOX3                   1010
#define IDC_COLORBOX4                   1011
#define IDC_COLORBOX6                   1012
#define IDC_COLORBOX5                   1013
#define IDC_COLORBOX7                   1014
#define IDC_COLORBOX8                   1015
#define IDC_RADIOOWNCOLORS              1016
#define IDC_RADIOSYSCOLORS              1017
#define IDC_THEMES                      1018
#define IDC_DELETE                      1019
#define IDC_ADDNEW                      1020
#define IDC_EDIT1                       1021
#define IDC_ABOUT                       32771
#define IDC_CONFIGURE                   32772
#define IDC_EXIT                        32773
#define IDC_MYICON                      32774
#define IDC_SHOW                        32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
