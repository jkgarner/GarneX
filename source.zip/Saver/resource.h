//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MfcSaver.rc
//
#define IDS_ROMAN                       2
#define IDS_ARABIC                      3
#define IDD_MFCSAVER_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDB_ICONS                       129
#define IDC_BUTTON1                     1000
#define IDC_ROMAN                       1000
#define IDC_SLIDER1                     1001
#define IDC_Rotate                      1001
#define IDC_SLIDER2                     1002
#define IDC_QUADONLY                    1002
#define IDC_X                           1003
#define IDC_Y                           1004
#define IDC_CX                          1005
#define IDC_CY                          1006
#define IDC_SMOOTH                      1007
#define IDC_COLORBOX1                   1008
#define IDC_COLORBOX2                   1009
#define IDC_COLORBOX3                   1010
#define IDC_COLORBOX4                   1011
#define IDC_COLORBOX6                   1012
#define IDC_COLORBOX5                   1013
#define IDC_COLORBOX7                   1014
#define IDC_COLORBOX8                   1015
#define IDC_COLORBOX9                   1016
#define IDC_SPEED                       1017
#define IDC_RADIO_CENTER                1018
#define IDC_RADIO_FIXED                 1019
#define IDC_RADIO_FLOATING              1020
#define IDC_RADIO_SYSBKG                1021
#define IDC_RADIO_BLACKBKG              1022
#define IDC_COLORBOX10                  1023
#define IDC_RADIO_0                     1024
#define IDC_RADIO_1                     1025
#define IDC_RADIO_2                     1026
#define IDC_RADIO_3                     1027
#define IDC_RADIO_4                     1028
#define IDC_RADIO_5                     1029
#define IDC_RADIO_DESKTOP               1030
#define IDC_CHECK1                      1031
#define IDC_WIPES                       1031
#define IDC_WIPES2                      1032
#define IDC_SHADOWS                     1032

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
